<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{domgoogleone}prestashop>domgoogleone_2d20cc07ac9d06e77a4af7d9ffdb95c8'] = 'Création ou Adaptation par Domi';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_652206976767150277dd920599d726f1'] = 'Google +1';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_fae6d25fce7c98826594287b3201051d'] = ' Ajout du bouton Google +1';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_25620a2d089a42e512a42c0dd8d46911'] = 'Création Domi : Ajout du bouton Google +1';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_e9b15b1e95238fafad933dafc24feab2'] = 'Ce module ajoute dans vos pages le bouton +1 Google';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_83c815afa0e8015bed7035360a91541c'] = 'Etes vous certain de vouloir désinstaller ce module';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour effectuée';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_958e407a13a335bf07ded95bb75316e5'] = 'Erreur lors de la mise à jour de la configuration';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuration';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_59044da6da866aa3b51c3daf342a20f6'] = 'Pour que le Gratuit ne devienne pas Payant';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_af645946859133f0fb13b23577b39ab5'] = 'Taille :';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_2660064e68655415da2628c2ae2f7592'] = 'Petit';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_87f8a6ab85c9ced3702b4ea641ad4bb5'] = 'Moyen';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_eb6d8ae6f20283755b339c0dc273988b'] = 'Standard';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_31fdedff3e473efdbd079e3b59fcb4f9'] = 'Grand';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_0885f0c211f74834f0109c5abaf4cdc4'] = 'Langue :';
$_MODULE['<{domgoogleone}prestashop>domgoogleone_3695db2febc4f6b75eb2200b14bfc3da'] = 'Afficher le total :';
